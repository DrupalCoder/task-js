
// loop showing enen numbers 
let num = 20;

for(let i = 1;i<=num; i++){
    console.log("this is i value before if",i)
    if(i % 2 == 0){
        console.log(i)
    }
}